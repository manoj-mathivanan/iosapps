//
//  UserLocation.m
//  PaloAltoTraining
//
//  Created by Frank Neumann on 11/21/12.
//  Copyright (c) 2012 SAP. All rights reserved.
//

#import "UserLocation.h"

@implementation UserLocation
- (id)initWithName:(NSString*)name address:(NSString*)address coordinate:(CLLocationCoordinate2D)coordinate {
    if ((self = [super init])) {
        _title = [name copy];
        _subtitle = [address copy];
        _coordinate = coordinate;
    }
    return self;
}
@end
