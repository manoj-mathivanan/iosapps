//
//  UserManager.h
//  MapViewFN
//
//  Created by Frank Neumann on 11/23/12.
//  Copyright (c) 2012 SAP. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol UserRetrievalDelegate <NSObject>

- (void) callFinished:(NSArray *) result;
- (void) callFailed:(NSString *) message;

@end

extern NSString * const COMPLETE_ADDRESS;
extern NSString * const DISPLAY_NAME;

@interface UserManager : NSObject

+ (id)getInstance;

- (bool) getUsersLocally;

@property (nonatomic,assign) id<UserRetrievalDelegate> delegate;

@end
