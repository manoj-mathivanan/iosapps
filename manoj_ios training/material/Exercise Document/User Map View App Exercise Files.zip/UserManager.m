//
//  UserManager.m
//  MapViewFN
//
//  Created by Frank Neumann on 11/23/12.
//  Copyright (c) 2012 SAP. All rights reserved.
//

#import "UserManager.h"

@implementation UserManager

NSString * const COMPLETE_ADDRESS = @"CompleteAddress";
NSString * const DISPLAY_NAME = @"T1.DISPLAY_NAME";

+ (id)getInstance
{
    static dispatch_once_t pred = 0;
    __strong static id _sharedObject = nil;
    dispatch_once(&pred, ^{
        _sharedObject = [[self alloc] init];
    });
    return _sharedObject;
}

- (bool) getUsersLocally {
    NSError *error = nil;
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"users" ofType:@"json"];
    
    NSString *responseString = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
    
    if (error) {
        NSLog(@"Failed to load file %@", path);
    }
    
    [self parseData:responseString];
    
    return YES;
}

- (void) parseData:(NSString *) message {
    NSLog(@"Start parsing");
    
    NSData* responseData = [message dataUsingEncoding:NSUTF8StringEncoding]; //NSString to NSData conversion
    
    NSError *error = nil;
    
    //Parse NSData containing JSON structure into NSDictionary, NSArray and NSString objects
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&error];
    
    if (error) {
        NSLog(@"JSON deserialization failed");
        [self.delegate performSelector:@selector(callFailed:) withObject:@"JSON deserialization failed"];
        
    } else {
        NSDictionary *resultList = [json objectForKey:@"resultList"];
        NSArray *result = [resultList objectForKey:@"result"];
        
        NSMutableArray *allRows = [NSMutableArray new];
        
        for (NSDictionary *rowDict in result) {
            NSArray *resultField = [rowDict objectForKey:@"resultField"];
            
            NSMutableDictionary *newRowDict = [NSMutableDictionary new];
            
            NSMutableDictionary *newColumnDict = nil;
            
            for (NSDictionary *columnDict in resultField) {
                newColumnDict = [NSMutableDictionary new];
                
                [newRowDict setObject:[columnDict objectForKey:@"fieldValue"] forKey:[columnDict objectForKey:@"fieldId"]];
                
                [newColumnDict release];
            }
            
            NSString *completeAddress = [self buildAddress:newRowDict];
            if (completeAddress){
                [newRowDict setObject:[self buildAddress:newRowDict] forKey:COMPLETE_ADDRESS];
            }
            
            [allRows addObject:newRowDict];
            [newRowDict release];
        }
        
        [self.delegate performSelector:@selector(callFinished:) withObject:allRows];
        
        [allRows release];
    }
    
    NSLog(@"Done Parsing");
}

- (NSString*) buildAddress:(NSDictionary *) addressPieces {
    NSString *address1 = [addressPieces objectForKey:@"T1.ADDRESS_1"];
    NSString *city = [addressPieces objectForKey:@"T1.CITY"];
    NSString *state = [addressPieces objectForKey:@"T1.STATE_PROVINCE"];
    
    NSString *completeAddress = nil;
    
    if ([self isEmptyString:address1] || [self isEmptyString:city] || [self isEmptyString:state]) {
        completeAddress = nil;
    } else {
        completeAddress = [NSString stringWithFormat:@"%@, %@, %@", address1, city, state];
    }
    
    return completeAddress;
}

- (bool) isEmptyString:(NSString *) inputString {
    bool isEmpty = NO;
    
    if (inputString == (id)[NSNull null] || inputString == 0 || [inputString length] == 0){
        isEmpty = YES;
    }
    
    return isEmpty;
}

#pragma mark Base 64 encoding
- (NSString *)Base64EncodeStr:(NSString *)strData{
    NSData* data = [strData dataUsingEncoding:NSUTF8StringEncoding];
    return [self Base64Encode:data];
}

- (NSString *)Base64Encode:(NSData *)data{
    //Point to start of the data and set buffer sizes
    int inLength = [data length];
    int outLength = ((((inLength * 4)/3)/4)*4) + (((inLength * 4)/3)%4 ? 4 : 0);
    const char *inputBuffer = [data bytes];
    char *outputBuffer = malloc(outLength);
    outputBuffer[outLength] = 0;
    
    //64 digit code
    static char Encode[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    
    //start the count
    int cycle = 0;
    int inpos = 0;
    int outpos = 0;
    char temp;
    
    //Pad the last to bytes, the outbuffer must always be a multiple of 4
    outputBuffer[outLength-1] = '=';
    outputBuffer[outLength-2] = '=';
    
    while (inpos < inLength){
        switch (cycle) {
            case 0:
                outputBuffer[outpos++] = Encode[(inputBuffer[inpos]&0xFC)>>2];
                cycle = 1;
                break;
            case 1:
                temp = (inputBuffer[inpos++]&0x03)<<4;
                outputBuffer[outpos] = Encode[temp];
                cycle = 2;
                break;
            case 2:
                outputBuffer[outpos++] = Encode[temp|(inputBuffer[inpos]&0xF0)>> 4];
                temp = (inputBuffer[inpos++]&0x0F)<<2;
                outputBuffer[outpos] = Encode[temp];
                cycle = 3;
                break;
            case 3:
                outputBuffer[outpos++] = Encode[temp|(inputBuffer[inpos]&0xC0)>>6];
                cycle = 4;
                break;
            case 4:
                outputBuffer[outpos++] = Encode[inputBuffer[inpos++]&0x3f];
                cycle = 0;
                break;
            default:
                cycle = 0;
                break;
        }
    }
    NSString *pictemp = [NSString stringWithUTF8String:outputBuffer];
    free(outputBuffer);
    return pictemp;
}

@end
