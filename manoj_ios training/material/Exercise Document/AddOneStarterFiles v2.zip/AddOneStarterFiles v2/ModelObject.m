//
//  ModelObject.m
//  AddOne
//
//  Created by Rescue Mission Software on 2/12/11.
//  Copyright 2011 Rescue Mission Software. All rights reserved.

//  This class follows the recommended format for a Singleton Object found in Apple's "Cocoa Fundamentals Guide: Cocoa Objects"

//  The only change is that instead of a class method named "sharedManager," this class uses a method named "sharedInstance."    



#import "ModelObject.h"




@implementation ModelObject

static ModelObject *sharedModelObject = nil;

+ (ModelObject*)sharedInstance
{
    if (sharedModelObject == nil) {
        sharedModelObject = [[super allocWithZone:NULL] init];
    }
    return sharedModelObject;
}

+ (id)allocWithZone:(NSZone *)zone
{
    return [[self sharedInstance] retain];
}

- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id)retain
{
    return self;
}

- (NSUInteger)retainCount
{
    return NSUIntegerMax;  //denotes an object that cannot be released
}

- (oneway void)release
{
    //do nothing
}

- (id)autorelease
{
    return self;
}


@end
