/*
 *  LegacyCode.c
 *  AddOne
 *
 *  Created by Rescue Mission Software on 2/12/11.
 *  Copyright 2011 Rescue Mission Software. All rights reserved.
 *
 */

#include "LegacyCode.h"


int legacyAddOne (int inputNumber)
{
	return inputNumber + 1;
}

