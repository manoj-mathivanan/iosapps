//
//  ViewController.m
//  DemoClassUsage
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "ViewController.h"
#import "Employee.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    
    Employee *empObj1 = [[Employee alloc]init];
    empObj1.empName =@"Manikandan";
    empObj1.empRole =@"Developer";
    [empObj1 printEmployeeName];
    NSLog(@"%@",[empObj1 getEmployeeName]);
    
    
    [empObj1 greetEmployeeWith:@"Hi " withMessage:@" Welcome to iOS"];
    
    [empObj1 greetEmployeeWith:@"Dear " withMessage:[empObj1 getEmployeeName]];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
