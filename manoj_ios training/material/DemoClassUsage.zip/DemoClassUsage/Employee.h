//
//  Employee.h
//  DemoClassUsage
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Employee : NSObject
{
    NSString *empID;
}
@property(nonatomic) NSString *empName;
@property(nonatomic) NSString *empRole;




-(void)printEmployeeName;
-(NSString*) getEmployeeName;
-(NSString*) greetEmployeeWith:(NSString*)adMsg withMessage:(NSString*)msg;


@end
