//
//  Employee.m
//  DemoClassUsage
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "Employee.h"

@implementation Employee

-(void)printEmployeeName
{
    NSLog(@"Employee Name : %@" , [self empName]);
}
-(NSString*) getEmployeeName
{
    //[empID];
    
    NSMutableArray
    
    return [self empName];
}
-(NSString*) greetEmployeeWith:(NSString*)adMsg withMessage:(NSString*)msg
{
    NSLog(@"%@",adMsg);
      NSLog(@"%@",[self empName]);
      NSLog(@"%@",msg);
    [self internalMethod:[self empName] withMessage:@"Am internally decided msg"];
    return nil;
}

-(NSString*) internalMethod:(NSString*)eName withMessage:(NSString*)msg
{
    NSLog(@"Am in private Usage");
    return nil;
}

@end
