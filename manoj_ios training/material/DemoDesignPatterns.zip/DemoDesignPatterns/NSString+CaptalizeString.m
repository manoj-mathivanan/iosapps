//
//  NSString+CaptalizeString.m
//  DemoDesignPatterns
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "NSString+CaptalizeString.h"

@implementation NSString (CaptalizeString)

-(NSString*) myconvertToUpperString
{
    return [self uppercaseString];
}

@end
