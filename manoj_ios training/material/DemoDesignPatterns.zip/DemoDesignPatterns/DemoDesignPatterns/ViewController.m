//
//  ViewController.m
//  DemoDesignPatterns
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "ViewController.h"
#import "Employee.h"
#import "BankDetail.h"
#import "ProtocolEntityUsage.h"

#import "StorageManager.h"

#import "IOSPrinter.h"
#import "DigitalPrinter.h"

#import "Manager.h"


#import "NSString+CaptalizeString.h"
#import "NSString+MaskString.h"
#import "NSString+SpecialCharacterConverter.h"
#import "NSString+ManiString.h"

@protocol ProtocolEntityUsage;

@interface ViewController ()
{
    id<ProtocolEntityUsage> entityUsageObj;
    id<SecureEntity> secureEntityObj;
}

@end

@implementation ViewController

- (void)viewDidLoad
{
    /*
    NSString  *myString =@"manikandan+developer-time*practice = ( NO TIME )";
    NSLog(@"%@",myString.myconvertToUpperString);
    NSLog(@"%@",myString.convertMathematicalOperators);    
    NSLog(@"%@",myString.maskString);
    NSLog(@"%@",[myString xconvertOriginalString:@"a" withString:@"_"]);
    NSString *myAnotherString = @"abcdef";
    NSLog(@"%@",[myAnotherString maskString]);
     */
  
   //Employee *empObj = [[Employee alloc]init];
   // [empObj printEntityName];
   // [empObj entityTraceStart];
/*    entityUsageObj = [[Employee alloc] init];
    [entityUsageObj printEntityName];
    
     secureEntityObj = [[BankDetail alloc] init];
    [secureEntityObj makeEntityTracingSecure:TRUE];
    
    secureEntityObj = [[Employee alloc] init];
    [secureEntityObj makeEntityTracingSecure:TRUE];
*/
    
   /*
    StorageManager *sManager = [StorageManager sharedStorageManager];
    [sManager printValue];
    StorageManager *sManager1 = [[StorageManager alloc]init];
    [sManager1 printValue];
    if([sManager isEqual:sManager1])
    {
        NSLog(@"Am Same Contents");
        
    }
    
    
    UIDevice *device = [[UIDevice alloc] init];
    NSLog(@"%@",[device systemName]);
    UIDevice *d = [UIDevice currentDevice];
    NSLog(@"%@ %@",[d systemName] ,[d systemVersion]);
    if(sManager == sManager1)
    {
        NSLog(@"Objects are Same");
    }
    */
    /*
   IOSPrinter *pri = [[IOSPrinter alloc]init];
pri.delegate = [[DigitalPrinter alloc]init];
    [pri printFromIOS];
    [pri printDefault];
 */
    /*
    Manager *mObj = [[Manager alloc] init];
    [mObj printManagerName];
    [mObj makeEntityTracingSecure:TRUE ];
  */
   
    /*Employee *empObj1 = [[Employee alloc] init];
    [empObj1 entityTraceStart];
    [empObj1 entityTraceStop];
    [empObj1 makeEntityTracingSecure:TRUE];
    
    BankDetail *bankObj1 = [[BankDetail alloc]init];
    [bankObj1 makeEntityTracingSecure:TRUE];
    */
    
    NSString *myStr = @"abcdefgh";
    //[myStr printStringWithManiStringMsg];
    
    [myStr maskString];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
