//
//  StorageManager.h
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StorageManager : NSObject
{
    NSString *storageValue;
}

@property(nonatomic, retain) NSString *storageValue;

+(id)sharedStorageManager;

-(void) printValue;

@end
