//
//  IOSPrinter.m
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "IOSPrinter.h"

@implementation IOSPrinter


-(void) printFromIOS
{
    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(printDefault)]) {

        [self.delegate printDefault];
    }else{
        NSLog(@"No");
    }
    
 
}

-(void) printDefault
{
    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(printDefault)]) {
        
        [self.delegate printDefault];
        NSLog(@"Am also Implementing !");
    }
}

@end
