//
//  Employee.m
//  DemoDesignPatterns
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "Employee.h"

@implementation Employee

-(void) printEntityName
{
    NSLog(@"Entity Name : Employee " );
}

-(void) entityTraceStart
{
    NSLog(@"Tracing Start");
}
-(void) entityTraceStop
{
    NSLog(@"Tracing Stop"); 
}

-(void) makeEntityTracingSecure:(BOOL)enable
{
    NSLog(@"Enabled 3");
}

@end
