//
//  Manager.m
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "Manager.h"

@implementation Manager

-(void) printManagerName
{
    NSLog(@"Steve");
}

@end
