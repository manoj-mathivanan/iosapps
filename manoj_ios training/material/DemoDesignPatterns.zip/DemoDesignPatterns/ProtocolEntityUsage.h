//
//  ProtocolEntityUsage.h
//  DemoDesignPatterns
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ProtocolEntityUsage <NSObject>

@required

-(void) printEntityName;
-(void) entityTraceStart;
-(void) entityTraceStop;

@optional
-(id) getEntityRuntimeName;

@end

@protocol SecureEntity <NSObject>

@required
-(void) makeEntityTracingSecure:(BOOL)enable;

@end