//
//  NSString+ManiString.m
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "NSString+ManiString.h"

@implementation NSString (ManiString)

-(void) printStringWithManiStringMsg
{
    NSLog(@"Mani_ %@",self);
}


-(NSString*) maskString
{
    NSLog(@"Masked");
    return nil;
}

@end
