//
//  Manager.h
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ProtocolEntityUsage.h"

@interface Manager : NSObject<SecureEntity>


-(void) printManagerName;

@end
