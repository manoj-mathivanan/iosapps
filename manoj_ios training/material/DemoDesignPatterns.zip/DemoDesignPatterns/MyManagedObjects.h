//
//  MyManagedObjects.h
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MyManagedObjects <NSObject>

-(void) printMyManagedObjectUsage;

@end
