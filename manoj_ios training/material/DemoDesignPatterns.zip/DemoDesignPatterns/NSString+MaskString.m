//
//  NSString+MaskString.m
//  DemoDesignPatterns
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "NSString+MaskString.h"

@implementation NSString (MaskString)

-(NSString*) maskString
{
    NSMutableString *str = [[NSMutableString alloc]init];
    for(int i=0;i<self.length;i++)
    {
        [str appendString:@"*"];
    }
    
    return str;
}

@end
