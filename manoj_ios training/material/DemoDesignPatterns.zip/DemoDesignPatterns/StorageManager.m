//
//  StorageManager.m
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "StorageManager.h"

@implementation StorageManager

@synthesize storageValue;

+(id)sharedStorageManager
{
     static StorageManager *myManager = nil;
    @synchronized(self)
    {
        if(myManager ==nil)
        {
            myManager =  [[StorageManager alloc]init];
            NSLog(@"Created");
        }
    }
    return myManager;
}


-(void) printValue
{
    NSLog(@"Am always SIngleton");
}

@end
