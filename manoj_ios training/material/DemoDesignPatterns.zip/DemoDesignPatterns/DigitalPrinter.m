//
//  DigitalPrinter.m
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "DigitalPrinter.h"

@implementation DigitalPrinter


-(void) printDefault
{
    NSLog(@"Am Default Printing.....");
}

-(void) printWithSpecification:(NSString*)paperSize
{
    
    NSLog(@"Am Custom Paper Size Print, Paper Size is : %@. Printing.....",paperSize);
}


@end
