//
//  NSString+ManiString.h
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ManiString)

-(void) printStringWithManiStringMsg;


-(NSString*) maskString;


@end
