//
//  Employee.h
//  DemoDesignPatterns
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ProtocolEntityUsage.h"

@interface Employee : NSObject<ProtocolEntityUsage,SecureEntity>

-(void) printEntityName;

@end
