//
//  NSString+SpecialCharacterConverter.m
//  DemoDesignPatterns
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "NSString+SpecialCharacterConverter.h"

@implementation NSString (SpecialCharacterConverter)

-(NSString *) xconvertOriginalString:(NSString*)lookupString withString:(NSString*)pattern
{
    return [self stringByReplacingOccurrencesOfString:lookupString withString:pattern];
}



-(NSString *) convertMathematicalOperators
{
   return [[[[[[self stringByReplacingOccurrencesOfString:@"+" withString:@"_"] stringByReplacingOccurrencesOfString:@"-" withString:@"_"] stringByReplacingOccurrencesOfString:@"*" withString:@"_"] stringByReplacingOccurrencesOfString:@"=" withString:@"_"] stringByReplacingOccurrencesOfString:@"(" withString:@"_"] stringByReplacingOccurrencesOfString:@")" withString:@"_"];
}


-(NSString *) xconvertMathematicalOperators:(NSString*)pattern
{
    
}



@end
