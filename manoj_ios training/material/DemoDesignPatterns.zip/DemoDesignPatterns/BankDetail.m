//
//  BankDetail.m
//  DemoDesignPatterns
//
//  Created by iMani on 16/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import "BankDetail.h"

@implementation BankDetail

-(void) makeEntityTracingSecure:(BOOL)enable
{
    NSLog(@"Enabled");
}
@end
