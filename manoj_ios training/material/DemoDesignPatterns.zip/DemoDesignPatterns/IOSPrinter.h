//
//  IOSPrinter.h
//  DemoDesignPatterns
//
//  Created by iMani on 17/04/13.
//  Copyright (c) 2013 test. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PrinterDelegate.h"

@interface IOSPrinter : NSObject<PrinterDelegate>

@property(nonatomic) id<PrinterDelegate> delegate;


-(void) printFromIOS;

@end
