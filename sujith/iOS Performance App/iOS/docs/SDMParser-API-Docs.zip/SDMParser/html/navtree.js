var NAVTREE =
[
  [ "SAP OData Mobile SDK iOS", "index.html", [
    [ "Class List", "annotated.html", [
      [ "NSMutableString(ConversionExtensions)", "interface_n_s_mutable_string_07_conversion_extensions_08.html", null ],
      [ "NSString(ConversionExtension)", "interface_n_s_string_07_conversion_extension_08.html", null ],
      [ "NSString(NSStringExtensions)", "interface_n_s_string_07_n_s_string_extensions_08.html", null ],
      [ "SDMCache", "interface_s_d_m_cache.html", null ],
      [ "SDMCacheException", "interface_s_d_m_cache_exception.html", null ],
      [ "<SDMCaching>", "protocol_s_d_m_caching-p.html", null ],
      [ "SDMDuration", "interface_s_d_m_duration.html", null ],
      [ "SDMFunctionImportResultParser", "interface_s_d_m_function_import_result_parser.html", null ],
      [ "SDMGenericParser", "interface_s_d_m_generic_parser.html", null ],
      [ "SDMODataActionLink", "interface_s_d_m_o_data_action_link.html", null ],
      [ "SDMODataCollection", "interface_s_d_m_o_data_collection.html", null ],
      [ "SDMODataDataParser", "interface_s_d_m_o_data_data_parser.html", null ],
      [ "SDMODataEntitySchema", "interface_s_d_m_o_data_entity_schema.html", null ],
      [ "SDMODataEntry", "interface_s_d_m_o_data_entry.html", null ],
      [ "SDMODataEntryXML", "interface_s_d_m_o_data_entry_x_m_l.html", null ],
      [ "SDMODataError", "interface_s_d_m_o_data_error.html", null ],
      [ "SDMODataErrorXMLParser", "interface_s_d_m_o_data_error_x_m_l_parser.html", null ],
      [ "SDMODataFunctionImport", "interface_s_d_m_o_data_function_import.html", null ],
      [ "SDMODataFunctionImportParameter", "interface_s_d_m_o_data_function_import_parameter.html", null ],
      [ "SDMODataIconInfo", "interface_s_d_m_o_data_icon_info.html", null ],
      [ "SDMODataLink", "interface_s_d_m_o_data_link.html", null ],
      [ "SDMODataMediaResourceLink", "interface_s_d_m_o_data_media_resource_link.html", null ],
      [ "SDMODataMetaDocumentParser", "interface_s_d_m_o_data_meta_document_parser.html", null ],
      [ "SDMODataPropertyInfo", "interface_s_d_m_o_data_property_info.html", null ],
      [ "SDMODataPropertyValueBinary", "interface_s_d_m_o_data_property_value_binary.html", null ],
      [ "SDMODataPropertyValueBoolean", "interface_s_d_m_o_data_property_value_boolean.html", null ],
      [ "SDMODataPropertyValueComplex", "interface_s_d_m_o_data_property_value_complex.html", null ],
      [ "SDMODataPropertyValueDateTime", "interface_s_d_m_o_data_property_value_date_time.html", null ],
      [ "SDMODataPropertyValueDateTimeOffset", "interface_s_d_m_o_data_property_value_date_time_offset.html", null ],
      [ "SDMODataPropertyValueDecimal", "interface_s_d_m_o_data_property_value_decimal.html", null ],
      [ "SDMODataPropertyValueDouble", "interface_s_d_m_o_data_property_value_double.html", null ],
      [ "SDMODataPropertyValueFactory", "interface_s_d_m_o_data_property_value_factory.html", null ],
      [ "SDMODataPropertyValueGuid", "interface_s_d_m_o_data_property_value_guid.html", null ],
      [ "SDMODataPropertyValueInt", "interface_s_d_m_o_data_property_value_int.html", null ],
      [ "SDMODataPropertyValueObject", "interface_s_d_m_o_data_property_value_object.html", null ],
      [ "SDMODataPropertyValueSingle", "interface_s_d_m_o_data_property_value_single.html", null ],
      [ "SDMODataPropertyValueString", "interface_s_d_m_o_data_property_value_string.html", null ],
      [ "SDMODataPropertyValueTime", "interface_s_d_m_o_data_property_value_time.html", null ],
      [ "SDMODataRelatedLink", "interface_s_d_m_o_data_related_link.html", null ],
      [ "SDMODataSchema", "interface_s_d_m_o_data_schema.html", null ],
      [ "SDMODataServiceDocument", "interface_s_d_m_o_data_service_document.html", null ],
      [ "SDMODataServiceDocumentParser", "interface_s_d_m_o_data_service_document_parser.html", null ],
      [ "SDMODataWorkspace", "interface_s_d_m_o_data_workspace.html", null ],
      [ "SDMOpenSearchDescription", "interface_s_d_m_open_search_description.html", null ],
      [ "SDMOpenSearchDescriptionURLTemplate", "interface_s_d_m_open_search_description_u_r_l_template.html", null ],
      [ "SDMOpenSearchDescriptionXMLParser", "interface_s_d_m_open_search_description_x_m_l_parser.html", null ],
      [ "<SDMParserDelegate>", "protocol_s_d_m_parser_delegate-p.html", null ],
      [ "SDMParserException", "interface_s_d_m_parser_exception.html", null ],
      [ "SDMPerformanceUtil", "interface_s_d_m_performance_util.html", null ],
      [ "SDMPersistence", "interface_s_d_m_persistence.html", null ],
      [ "<SDMPersisting>", "protocol_s_d_m_persisting-p.html", null ],
      [ "SDMSubscriptionInfo", "interface_s_d_m_subscription_info.html", null ],
      [ "SDMSubscriptionXML", "interface_s_d_m_subscription_x_m_l.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "NSMutableString(ConversionExtensions)", "interface_n_s_mutable_string_07_conversion_extensions_08.html", null ],
      [ "NSString(ConversionExtension)", "interface_n_s_string_07_conversion_extension_08.html", null ],
      [ "NSString(NSStringExtensions)", "interface_n_s_string_07_n_s_string_extensions_08.html", null ],
      [ "SDMCacheException", "interface_s_d_m_cache_exception.html", null ],
      [ "<SDMCaching>", "protocol_s_d_m_caching-p.html", [
        [ "SDMCache", "interface_s_d_m_cache.html", null ]
      ] ],
      [ "SDMDuration", "interface_s_d_m_duration.html", null ],
      [ "SDMODataCollection", "interface_s_d_m_o_data_collection.html", null ],
      [ "SDMODataEntitySchema", "interface_s_d_m_o_data_entity_schema.html", null ],
      [ "SDMODataEntry", "interface_s_d_m_o_data_entry.html", null ],
      [ "SDMODataEntryXML", "interface_s_d_m_o_data_entry_x_m_l.html", null ],
      [ "SDMODataError", "interface_s_d_m_o_data_error.html", null ],
      [ "SDMODataFunctionImport", "interface_s_d_m_o_data_function_import.html", null ],
      [ "SDMODataFunctionImportParameter", "interface_s_d_m_o_data_function_import_parameter.html", null ],
      [ "SDMODataIconInfo", "interface_s_d_m_o_data_icon_info.html", null ],
      [ "SDMODataLink", "interface_s_d_m_o_data_link.html", [
        [ "SDMODataActionLink", "interface_s_d_m_o_data_action_link.html", null ],
        [ "SDMODataMediaResourceLink", "interface_s_d_m_o_data_media_resource_link.html", null ],
        [ "SDMODataRelatedLink", "interface_s_d_m_o_data_related_link.html", null ]
      ] ],
      [ "SDMODataPropertyInfo", "interface_s_d_m_o_data_property_info.html", null ],
      [ "SDMODataPropertyValueFactory", "interface_s_d_m_o_data_property_value_factory.html", null ],
      [ "SDMODataPropertyValueObject", "interface_s_d_m_o_data_property_value_object.html", [
        [ "SDMODataPropertyValueBinary", "interface_s_d_m_o_data_property_value_binary.html", null ],
        [ "SDMODataPropertyValueBoolean", "interface_s_d_m_o_data_property_value_boolean.html", null ],
        [ "SDMODataPropertyValueComplex", "interface_s_d_m_o_data_property_value_complex.html", null ],
        [ "SDMODataPropertyValueDateTime", "interface_s_d_m_o_data_property_value_date_time.html", [
          [ "SDMODataPropertyValueDateTimeOffset", "interface_s_d_m_o_data_property_value_date_time_offset.html", null ]
        ] ],
        [ "SDMODataPropertyValueDecimal", "interface_s_d_m_o_data_property_value_decimal.html", null ],
        [ "SDMODataPropertyValueDouble", "interface_s_d_m_o_data_property_value_double.html", null ],
        [ "SDMODataPropertyValueGuid", "interface_s_d_m_o_data_property_value_guid.html", null ],
        [ "SDMODataPropertyValueInt", "interface_s_d_m_o_data_property_value_int.html", null ],
        [ "SDMODataPropertyValueSingle", "interface_s_d_m_o_data_property_value_single.html", null ],
        [ "SDMODataPropertyValueString", "interface_s_d_m_o_data_property_value_string.html", null ],
        [ "SDMODataPropertyValueTime", "interface_s_d_m_o_data_property_value_time.html", null ]
      ] ],
      [ "SDMODataSchema", "interface_s_d_m_o_data_schema.html", null ],
      [ "SDMODataServiceDocument", "interface_s_d_m_o_data_service_document.html", null ],
      [ "SDMODataWorkspace", "interface_s_d_m_o_data_workspace.html", null ],
      [ "SDMOpenSearchDescription", "interface_s_d_m_open_search_description.html", null ],
      [ "SDMOpenSearchDescriptionURLTemplate", "interface_s_d_m_open_search_description_u_r_l_template.html", null ],
      [ "<SDMParserDelegate>", "protocol_s_d_m_parser_delegate-p.html", [
        [ "SDMGenericParser", "interface_s_d_m_generic_parser.html", [
          [ "SDMFunctionImportResultParser", "interface_s_d_m_function_import_result_parser.html", null ],
          [ "SDMODataDataParser", "interface_s_d_m_o_data_data_parser.html", null ],
          [ "SDMODataErrorXMLParser", "interface_s_d_m_o_data_error_x_m_l_parser.html", null ],
          [ "SDMODataMetaDocumentParser", "interface_s_d_m_o_data_meta_document_parser.html", null ],
          [ "SDMODataServiceDocumentParser", "interface_s_d_m_o_data_service_document_parser.html", null ],
          [ "SDMOpenSearchDescriptionXMLParser", "interface_s_d_m_open_search_description_x_m_l_parser.html", null ]
        ] ]
      ] ],
      [ "SDMParserException", "interface_s_d_m_parser_exception.html", null ],
      [ "SDMPerformanceUtil", "interface_s_d_m_performance_util.html", null ],
      [ "<SDMPersisting>", "protocol_s_d_m_persisting-p.html", [
        [ "SDMPersistence", "interface_s_d_m_persistence.html", null ]
      ] ],
      [ "SDMSubscriptionInfo", "interface_s_d_m_subscription_info.html", null ],
      [ "SDMSubscriptionXML", "interface_s_d_m_subscription_x_m_l.html", null ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "File List", "files.html", [
      [ "usr/local/include/NSStringConversionExtension.h", "_n_s_string_conversion_extension_8h.html", null ],
      [ "usr/local/include/NSStringExtension.h", "_n_s_string_extension_8h.html", null ],
      [ "usr/local/include/SDMCache.h", "_s_d_m_cache_8h.html", null ],
      [ "usr/local/include/SDMCacheException.h", "_s_d_m_cache_exception_8h.html", null ],
      [ "usr/local/include/SDMCaching.h", "_s_d_m_caching_8h.html", null ],
      [ "usr/local/include/SDMFunctionImportResultParser.h", "_s_d_m_function_import_result_parser_8h.html", null ],
      [ "usr/local/include/SDMGenericParser.h", "_s_d_m_generic_parser_8h.html", null ],
      [ "usr/local/include/SDMOData.h", "_s_d_m_o_data_8h.html", null ],
      [ "usr/local/include/SDMODataCollection.h", "_s_d_m_o_data_collection_8h.html", null ],
      [ "usr/local/include/SDMODataDataParser.h", "_s_d_m_o_data_data_parser_8h.html", null ],
      [ "usr/local/include/SDMODataEntitySchema.h", "_s_d_m_o_data_entity_schema_8h.html", null ],
      [ "usr/local/include/SDMODataEntry.h", "_s_d_m_o_data_entry_8h.html", null ],
      [ "usr/local/include/SDMODataError.h", "_s_d_m_o_data_error_8h.html", null ],
      [ "usr/local/include/SDMODataErrorXMLParser.h", "_s_d_m_o_data_error_x_m_l_parser_8h.html", null ],
      [ "usr/local/include/SDMODataFunctionImport.h", "_s_d_m_o_data_function_import_8h.html", null ],
      [ "usr/local/include/SDMODataIconInfo.h", "_s_d_m_o_data_icon_info_8h.html", null ],
      [ "usr/local/include/SDMODataLink.h", "_s_d_m_o_data_link_8h.html", null ],
      [ "usr/local/include/SDMODataMetaDocumentParser.h", "_s_d_m_o_data_meta_document_parser_8h.html", null ],
      [ "usr/local/include/SDMODataProperty.h", "_s_d_m_o_data_property_8h.html", null ],
      [ "usr/local/include/SDMODataPropertyInfo.h", "_s_d_m_o_data_property_info_8h.html", null ],
      [ "usr/local/include/SDMODataPropertyValueFactory.h", "_s_d_m_o_data_property_value_factory_8h.html", null ],
      [ "usr/local/include/SDMODataPropertyValues.h", "_s_d_m_o_data_property_values_8h.html", null ],
      [ "usr/local/include/SDMODataSchema.h", "_s_d_m_o_data_schema_8h.html", null ],
      [ "usr/local/include/SDMODataServiceDocument.h", "_s_d_m_o_data_service_document_8h.html", null ],
      [ "usr/local/include/SDMODataServiceDocumentParser.h", "_s_d_m_o_data_service_document_parser_8h.html", null ],
      [ "usr/local/include/SDMODataWorkspace.h", "_s_d_m_o_data_workspace_8h.html", null ],
      [ "usr/local/include/SDMODataXMLBuilder.h", "_s_d_m_o_data_x_m_l_builder_8h.html", null ],
      [ "usr/local/include/SDMOpenSearchDescription.h", "_s_d_m_open_search_description_8h.html", null ],
      [ "usr/local/include/SDMOpenSearchDescriptionXMLParser.h", "_s_d_m_open_search_description_x_m_l_parser_8h.html", null ],
      [ "usr/local/include/SDMParser.h", "_s_d_m_parser_8h.html", null ],
      [ "usr/local/include/SDMParserDelegate.h", "_s_d_m_parser_delegate_8h.html", null ],
      [ "usr/local/include/SDMParserException.h", "_s_d_m_parser_exception_8h.html", null ],
      [ "usr/local/include/SDMPerformanceUtil.h", "_s_d_m_performance_util_8h.html", null ],
      [ "usr/local/include/SDMPersistence.h", "_s_d_m_persistence_8h.html", null ],
      [ "usr/local/include/SDMPersisting.h", "_s_d_m_persisting_8h.html", null ],
      [ "usr/local/include/SDMSubscriptionXMLBuilder.h", "_s_d_m_subscription_x_m_l_builder_8h.html", null ]
    ] ],
    [ "File Members", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

